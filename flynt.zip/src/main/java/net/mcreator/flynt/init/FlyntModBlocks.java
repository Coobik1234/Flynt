
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.flynt.init;

import net.minecraft.world.level.block.Block;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.mcreator.flynt.block.VerticalFlintPlatesBlock;
import net.mcreator.flynt.block.SmoothFlintBlockBlock;
import net.mcreator.flynt.block.LittleFlintBricksBlock;
import net.mcreator.flynt.block.HorizontalFlintPlatesBlock;
import net.mcreator.flynt.block.FlinttrapdoorBlock;
import net.mcreator.flynt.block.FlintTilesBlock;
import net.mcreator.flynt.block.FlintSquareBricksBlock;
import net.mcreator.flynt.block.FlintDoorBlock;
import net.mcreator.flynt.block.FlintBricksBlock;
import net.mcreator.flynt.block.FlintBigBricksBlock;
import net.mcreator.flynt.block.BlockOfFlintBlock;
import net.mcreator.flynt.FlyntMod;

public class FlyntModBlocks {
	public static Block BLOCK_OF_FLINT;
	public static Block SMOOTH_FLINT_BLOCK;
	public static Block FLINT_BRICKS;
	public static Block FLINT_BIG_BRICKS;
	public static Block FLINT_SQUARE_BRICKS;
	public static Block FLINT_TILES;
	public static Block VERTICAL_FLINT_PLATES;
	public static Block HORIZONTAL_FLINT_PLATES;
	public static Block LITTLE_FLINT_BRICKS;
	public static Block FLINT_DOOR;
	public static Block FLINTTRAPDOOR;

	public static void load() {
		BLOCK_OF_FLINT = Registry.register(BuiltInRegistries.BLOCK, new ResourceLocation(FlyntMod.MODID, "block_of_flint"), new BlockOfFlintBlock());
		SMOOTH_FLINT_BLOCK = Registry.register(BuiltInRegistries.BLOCK, new ResourceLocation(FlyntMod.MODID, "smooth_flint_block"), new SmoothFlintBlockBlock());
		FLINT_BRICKS = Registry.register(BuiltInRegistries.BLOCK, new ResourceLocation(FlyntMod.MODID, "flint_bricks"), new FlintBricksBlock());
		FLINT_BIG_BRICKS = Registry.register(BuiltInRegistries.BLOCK, new ResourceLocation(FlyntMod.MODID, "flint_big_bricks"), new FlintBigBricksBlock());
		FLINT_SQUARE_BRICKS = Registry.register(BuiltInRegistries.BLOCK, new ResourceLocation(FlyntMod.MODID, "flint_square_bricks"), new FlintSquareBricksBlock());
		FLINT_TILES = Registry.register(BuiltInRegistries.BLOCK, new ResourceLocation(FlyntMod.MODID, "flint_tiles"), new FlintTilesBlock());
		VERTICAL_FLINT_PLATES = Registry.register(BuiltInRegistries.BLOCK, new ResourceLocation(FlyntMod.MODID, "vertical_flint_plates"), new VerticalFlintPlatesBlock());
		HORIZONTAL_FLINT_PLATES = Registry.register(BuiltInRegistries.BLOCK, new ResourceLocation(FlyntMod.MODID, "horizontal_flint_plates"), new HorizontalFlintPlatesBlock());
		LITTLE_FLINT_BRICKS = Registry.register(BuiltInRegistries.BLOCK, new ResourceLocation(FlyntMod.MODID, "little_flint_bricks"), new LittleFlintBricksBlock());
		FLINT_DOOR = Registry.register(BuiltInRegistries.BLOCK, new ResourceLocation(FlyntMod.MODID, "flint_door"), new FlintDoorBlock());
		FLINTTRAPDOOR = Registry.register(BuiltInRegistries.BLOCK, new ResourceLocation(FlyntMod.MODID, "flinttrapdoor"), new FlinttrapdoorBlock());
	}

	public static void clientLoad() {
		BlockOfFlintBlock.clientInit();
		SmoothFlintBlockBlock.clientInit();
		FlintBricksBlock.clientInit();
		FlintBigBricksBlock.clientInit();
		FlintSquareBricksBlock.clientInit();
		FlintTilesBlock.clientInit();
		VerticalFlintPlatesBlock.clientInit();
		HorizontalFlintPlatesBlock.clientInit();
		LittleFlintBricksBlock.clientInit();
		FlintDoorBlock.clientInit();
		FlinttrapdoorBlock.clientInit();
	}
}
