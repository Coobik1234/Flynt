/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.flynt.init;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.mcreator.flynt.FlyntMod;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;

public class FlyntModItems {
	public static Item BLOCK_OF_FLINT;
	public static Item SMOOTH_FLINT_BLOCK;
	public static Item FLINT_BRICKS;
	public static Item FLINT_BIG_BRICKS;
	public static Item FLINT_SQUARE_BRICKS;
	public static Item FLINT_TILES;
	public static Item VERTICAL_FLINT_PLATES;
	public static Item HORIZONTAL_FLINT_PLATES;
	public static Item LITTLE_FLINT_BRICKS;
	public static Item FLINT_DOOR;
	public static Item FLINTTRAPDOOR;

	public static void load() {
		BLOCK_OF_FLINT = Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(FlyntMod.MODID, "block_of_flint"), new BlockItem(FlyntModBlocks.BLOCK_OF_FLINT, new Item.Properties()));
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.BUILDING_BLOCKS).register(content -> content.accept(BLOCK_OF_FLINT));
		SMOOTH_FLINT_BLOCK = Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(FlyntMod.MODID, "smooth_flint_block"), new BlockItem(FlyntModBlocks.SMOOTH_FLINT_BLOCK, new Item.Properties()));
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.BUILDING_BLOCKS).register(content -> content.accept(SMOOTH_FLINT_BLOCK));
		FLINT_BRICKS = Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(FlyntMod.MODID, "flint_bricks"), new BlockItem(FlyntModBlocks.FLINT_BRICKS, new Item.Properties()));
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.BUILDING_BLOCKS).register(content -> content.accept(FLINT_BRICKS));
		FLINT_BIG_BRICKS = Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(FlyntMod.MODID, "flint_big_bricks"), new BlockItem(FlyntModBlocks.FLINT_BIG_BRICKS, new Item.Properties()));
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.BUILDING_BLOCKS).register(content -> content.accept(FLINT_BIG_BRICKS));
		FLINT_SQUARE_BRICKS = Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(FlyntMod.MODID, "flint_square_bricks"), new BlockItem(FlyntModBlocks.FLINT_SQUARE_BRICKS, new Item.Properties()));
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.BUILDING_BLOCKS).register(content -> content.accept(FLINT_SQUARE_BRICKS));
		FLINT_TILES = Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(FlyntMod.MODID, "flint_tiles"), new BlockItem(FlyntModBlocks.FLINT_TILES, new Item.Properties()));
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.BUILDING_BLOCKS).register(content -> content.accept(FLINT_TILES));
		VERTICAL_FLINT_PLATES = Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(FlyntMod.MODID, "vertical_flint_plates"), new BlockItem(FlyntModBlocks.VERTICAL_FLINT_PLATES, new Item.Properties()));
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.BUILDING_BLOCKS).register(content -> content.accept(VERTICAL_FLINT_PLATES));
		HORIZONTAL_FLINT_PLATES = Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(FlyntMod.MODID, "horizontal_flint_plates"), new BlockItem(FlyntModBlocks.HORIZONTAL_FLINT_PLATES, new Item.Properties()));
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.BUILDING_BLOCKS).register(content -> content.accept(HORIZONTAL_FLINT_PLATES));
		LITTLE_FLINT_BRICKS = Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(FlyntMod.MODID, "little_flint_bricks"), new BlockItem(FlyntModBlocks.LITTLE_FLINT_BRICKS, new Item.Properties()));
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.BUILDING_BLOCKS).register(content -> content.accept(LITTLE_FLINT_BRICKS));
		FLINT_DOOR = Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(FlyntMod.MODID, "flint_door"), new BlockItem(FlyntModBlocks.FLINT_DOOR, new Item.Properties()));
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.BUILDING_BLOCKS).register(content -> content.accept(FLINT_DOOR));
		FLINTTRAPDOOR = Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(FlyntMod.MODID, "flinttrapdoor"), new BlockItem(FlyntModBlocks.FLINTTRAPDOOR, new Item.Properties()));
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.BUILDING_BLOCKS).register(content -> content.accept(FLINTTRAPDOOR));
	}

	public static void clientLoad() {
	}
}
